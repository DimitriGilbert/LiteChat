import{ao as r,ap as n}from"./index-Z_fN5MK6.js";const t=(a,o)=>r.lang.round(n.parse(a)[o]);export{t as c};
