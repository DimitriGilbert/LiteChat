import{b as r}from"./_baseUniq-C0bb_mFs.js";var e=4;function a(o){return r(o,e)}export{a as c};
