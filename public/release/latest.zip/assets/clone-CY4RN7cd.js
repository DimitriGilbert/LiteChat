import{b as r}from"./_baseUniq-C5gN_mdA.js";var e=4;function a(o){return r(o,e)}export{a as c};
