import{b as r}from"./_baseUniq-BU0gJ92Z.js";var e=4;function a(o){return r(o,e)}export{a as c};
