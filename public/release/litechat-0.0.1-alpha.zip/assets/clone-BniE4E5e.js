import{b as r}from"./_baseUniq-Bvd19ayv.js";var e=4;function a(o){return r(o,e)}export{a as c};
