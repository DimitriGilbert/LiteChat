import{b as r}from"./_baseUniq-BTZFDKY9.js";var e=4;function a(o){return r(o,e)}export{a as c};
